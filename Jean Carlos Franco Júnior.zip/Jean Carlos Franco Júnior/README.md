# SAEP Java Web - Jean Carlos Franco Júnior

Requer JDK 17 ou superior (java e javac no PATH). H2 2.3.232 está incluído em sistema/lib/h2.jar. Não exige Maven, Python ou servidor externo.

Extraia o ZIP, abra sistema/iniciar.bat e acesse http://127.0.0.1:8000.
Login: admin / Saep@2026! (também tecnico e atendente com a mesma senha).

O primeiro início importa saep_db.sql no H2 em sistema/dados/saep.mv.db. O SQL possui três registros fictícios por tabela e pode ser executado em um banco H2 vazio. CPF: AES-256-GCM. Senhas: PBKDF2-HMAC-SHA256, salt e 600.000 iterações. A chave_demonstracao.txt serve apenas para importar a massa; a aplicação gera sistema/dados/cpf.key e recriptografa os CPFs. Preserve banco e chave local em backups. Sessões expiram após 30 minutos do login; logout e reinício encerram as sessões.

Clientes: cadastro, edição, exclusão e busca por nome, e-mail ou telefone. CPF válido e único. Equipamentos: cliente obrigatório e série única. Agendamentos: equipamento obrigatório, data, descrição e status; listagem ordenada com dados completos associados. Exclua dependentes antes de clientes/equipamentos. O mesmo equipamento não pode ter dois agendamentos no mesmo horário.

Entregas: documentacao.pdf, der.pdf, saep_db.sql e sistema/src (Main.java, Seed.java, Teste.java). Main usa HTTP Server do JDK, JDBC e HTML/CSS. Seed gera a massa SQL. Teste verifica via HTTP autenticação, busca, CRUD, integridade e segurança.

Para executar testes, a partir da raiz e sem uma pasta teste-java anterior:
```powershell
javac -encoding UTF-8 -cp sistema/lib/h2.jar -d sistema/bin sistema/src/*.java
java '-Djdk.net.unixdomain.tmpdir=./socket-unix-inexistente' -cp 'sistema/bin;sistema/lib/h2.jar' Teste
```
O parâmetro contorna uma falha de sockets Unix do JDK 23 no Windows, usando TCP. O iniciar.bat também aplica esse ajuste.

Uso local de avaliação. Para produção, configurar HTTPS, gestão de credenciais, política de acesso e permissões de arquivos. CPF só é mostrado após autenticação. Dados e credenciais de demonstração são fictícios.
H2: https://h2database.com - licenças MPL 2.0/EPL 1.0.
