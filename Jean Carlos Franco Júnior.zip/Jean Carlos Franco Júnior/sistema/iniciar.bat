@echo off
cd /d "%~dp0.."
if not exist sistema\bin mkdir sistema\bin
javac -encoding UTF-8 -cp sistema\lib\h2.jar -d sistema\bin sistema\src\Main.java
if errorlevel 1 exit /b 1
java -Djdk.net.unixdomain.tmpdir="%CD%\sistema\sem-socket-unix" -cp "sistema\bin;sistema\lib\h2.jar" Main
