import com.sun.net.httpserver.*;
import java.net.*;
import java.net.http.*;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
public class Teste {
 static HttpClient client=HttpClient.newBuilder().build();static String cookie="",csrf="",base;
 static HttpResponse<String> req(String method,String path,String form)throws Exception{var b=HttpRequest.newBuilder(URI.create(base+path));if(!cookie.isEmpty())b.header("Cookie",cookie);if(method.equals("POST"))b.header("Content-Type","application/x-www-form-urlencoded").POST(HttpRequest.BodyPublishers.ofString(form));else b.GET();var r=client.send(b.build(),HttpResponse.BodyHandlers.ofString());r.headers().firstValue("Set-Cookie").ifPresent(v->cookie=v.split(";")[0]);return r;}
 static void check(boolean v,String msg){if(!v)throw new AssertionError(msg);}
 static String data(String...kv){StringJoiner j=new StringJoiner("&");j.add("csrf="+csrf);for(int i=0;i<kv.length;i+=2)j.add(kv[i]+"="+URLEncoder.encode(kv[i+1],StandardCharsets.UTF_8));return j.toString();}
 static void status(String method,String path,String data,int code)throws Exception{check(req(method,path,data).statusCode()==code,path+" expected "+code);}
 static void login()throws Exception{status("POST","/login",data("usuario","admin","senha","Saep@2026!"),303);String body=req("GET","/","").body();var m=java.util.regex.Pattern.compile("name='csrf' value='([^']+)'").matcher(body);check(m.find(),"csrf");csrf=m.group(1);check(body.contains("Administrador"),"menu");}
 public static void main(String[]args)throws Exception{
  Main.home=Path.of("teste-java/sistema").toAbsolutePath();Files.createDirectories(Main.home);Files.copy(Path.of("saep_db.sql"),Main.home.getParent().resolve("saep_db.sql"),StandardCopyOption.REPLACE_EXISTING);Files.copy(Path.of("chave_demonstracao.txt"),Main.home.getParent().resolve("chave_demonstracao.txt"),StandardCopyOption.REPLACE_EXISTING);Main.initialize();
  for(String t:List.of("usuarios","clientes","equipamentos","agendamentos"))check(Main.query("SELECT COUNT(*) AS n FROM "+t).get(0).get("n").equals("3"),"massa "+t);
  check(!Main.query("SELECT cpf FROM clientes WHERE id=1").get(0).get("cpf").equals("52998224725"),"criptografia");
  HttpServer server=HttpServer.create(new InetSocketAddress("127.0.0.1",0),0);server.createContext("/",x->{try{Main.handle(x);}catch(Exception e){e.printStackTrace();try{Main.send(x,500,"erro");}catch(Exception ignored){}}});server.start();base="http://127.0.0.1:"+server.getAddress().getPort();
  try{
   status("GET","/clientes","",303);status("POST","/login",data("usuario","admin","senha","errada"),401);login();for(String t:Main.tables.keySet())status("GET","/"+t,"",200);
   String body=req("GET","/clientes?q=Ana","").body();check(body.contains("Ana Exemplo")&&!body.contains("Bruno Exemplo"),"busca");body=req("GET","/agendamentos","").body();check(body.indexOf("2026-10-02")<body.indexOf("2026-10-03")&&body.indexOf("2026-10-03")<body.indexOf("2026-10-04")&&body.contains("52998224725"),"ordenacao");
   status("POST","/clientes","csrf=errado",403);
   String c=data("nome","Teste","cpf","39053344705","telefone","11999999999","email","teste@example.com","endereco","Rua Teste");status("POST","/clientes",c,303);status("POST","/clientes",c,400);status("POST","/clientes",c+"&id=4",303);
   String e=data("cliente_id","4","tipo","TV","marca","Teste","modelo","A","numero_serie","X4");status("POST","/equipamentos",e,303);status("POST","/equipamentos",e.replace("cliente_id=4","cliente_id=999").replace("X4","X5"),400);status("POST","/equipamentos",e+"&id=4",303);
   String a=data("equipamento_id","4","dia","2026-12-01T10:00","descricao","Teste","status","Pendente");status("POST","/agendamentos",a,303);status("POST","/agendamentos",a,400);status("POST","/agendamentos",a+"&id=4",303);
   status("POST","/clientes",data("id","4","acao","excluir"),400);for(String t:List.of("agendamentos","equipamentos","clientes"))status("POST","/"+t,data("id","4","acao","excluir"),303);
   Main.sessions.replaceAll((id,s)->new Main.Session(s.name(),s.csrf(),0));status("GET","/","",303);login();status("POST","/logout",data(),303);status("GET","/","",303);
   System.out.println("OK: SQL (3 por tabela), criptografia, login, busca, CRUD, FK, duplicidade, CSRF, expiracao e logout.");
  }finally{server.stop(0);}
 }
}
