import com.sun.net.httpserver.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.sql.*;
import java.util.*;
import java.util.concurrent.*;
import java.security.*;
import javax.crypto.*;
import javax.crypto.spec.*;
import java.time.*;
import org.h2.tools.RunScript;

public class Main {
 static Path home=Path.of(System.getProperty("saep.home","sistema")).toAbsolutePath();
 static String url; static byte[] key;
 static SecureRandom random=new SecureRandom();
 static Map<String,Session> sessions=new ConcurrentHashMap<>();
 record Session(String name,String csrf,long expires){}
 static LinkedHashMap<String,List<String>> tables=new LinkedHashMap<>();
 static {tables.put("clientes",List.of("nome","cpf","telefone","email","endereco"));tables.put("equipamentos",List.of("cliente_id","tipo","marca","modelo","numero_serie"));tables.put("agendamentos",List.of("equipamento_id","dia","descricao","status"));}
 static String esc(Object v){return String.valueOf(v==null?"":v).replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;").replace("'","&#39;");}
 static String token(){byte[] b=new byte[32];random.nextBytes(b);return Base64.getUrlEncoder().withoutPadding().encodeToString(b);}
 static Connection db() throws SQLException{return DriverManager.getConnection(url,"sa","");}
 static List<Map<String,String>> query(String sql,Object...args)throws Exception{
  try(Connection c=db();PreparedStatement p=c.prepareStatement(sql)){for(int i=0;i<args.length;i++)p.setObject(i+1,args[i]);try(ResultSet r=p.executeQuery()){List<Map<String,String>> out=new ArrayList<>();while(r.next()){Map<String,String> row=new LinkedHashMap<>();for(int i=1;i<=r.getMetaData().getColumnCount();i++)row.put(r.getMetaData().getColumnLabel(i).toLowerCase(),r.getString(i));out.add(row);}return out;}}
 }
 static void update(String sql,List<String> args)throws Exception{try(Connection c=db();PreparedStatement p=c.prepareStatement(sql)){for(int i=0;i<args.size();i++)p.setString(i+1,args.get(i));if(p.executeUpdate()!=1)throw new IllegalArgumentException("Registro não encontrado.");}}
 static String hash(String password,byte[] salt)throws Exception{return Base64.getEncoder().encodeToString(salt)+"$"+Base64.getEncoder().encodeToString(SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(new PBEKeySpec(password.toCharArray(),salt,600000,256)).getEncoded());}
 static String hash(String p)throws Exception{byte[] s=new byte[16];random.nextBytes(s);return hash(p,s);}
 static boolean verify(String p,String h)throws Exception{return MessageDigest.isEqual(hash(p,Base64.getDecoder().decode(h.split("\\$")[0])).getBytes(StandardCharsets.UTF_8),h.getBytes(StandardCharsets.UTF_8));}
 static String encrypt(String plain)throws Exception{byte[] iv=new byte[12];random.nextBytes(iv);Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,new SecretKeySpec(key,"AES"),new GCMParameterSpec(128,iv));byte[] enc=c.doFinal(plain.getBytes(StandardCharsets.UTF_8));byte[] out=new byte[iv.length+enc.length];System.arraycopy(iv,0,out,0,12);System.arraycopy(enc,0,out,12,enc.length);return Base64.getEncoder().encodeToString(out);}
 static String decrypt(String text)throws Exception{byte[] b=Base64.getDecoder().decode(text);Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,new SecretKeySpec(key,"AES"),new GCMParameterSpec(128,Arrays.copyOf(b,12)));return new String(c.doFinal(Arrays.copyOfRange(b,12,b.length)),StandardCharsets.UTF_8);}
 static String fingerprint(String cpf)throws Exception{Mac m=Mac.getInstance("HmacSHA256");m.init(new SecretKeySpec(key,"HmacSHA256"));return Base64.getEncoder().encodeToString(m.doFinal(cpf.getBytes(StandardCharsets.UTF_8)));}
 static boolean validCpf(String v){if(!v.matches("[0-9]{11}")||v.chars().distinct().count()==1)return false;for(int n=9;n<=10;n++){int sum=0;for(int i=0;i<n;i++)sum+=(v.charAt(i)-48)*(n+1-i);int d=(sum*10)%11;if((d==10?0:d)!=v.charAt(n)-48)return false;}return true;}
 static Map<String,String> params(String q){Map<String,String> p=new HashMap<>();if(q!=null&&!q.isEmpty())for(String part:q.split("&")){String[] v=part.split("=",2);p.put(URLDecoder.decode(v[0],StandardCharsets.UTF_8),v.length==2?URLDecoder.decode(v[1],StandardCharsets.UTF_8):"");}return p;}
 static Session session(HttpExchange x){String cookie=x.getRequestHeaders().getFirst("Cookie");if(cookie!=null)for(String part:cookie.split(";")){String[] v=part.trim().split("=",2);if(v.length==2&&v[0].equals("sid")){Session s=sessions.get(v[1]);if(s!=null&&s.expires>System.currentTimeMillis())return s;sessions.remove(v[1]);}}return null;}
 static void send(HttpExchange x,int code,String body)throws Exception{byte[] b=body.getBytes(StandardCharsets.UTF_8);x.getResponseHeaders().set("Content-Type","text/html; charset=utf-8");x.getResponseHeaders().set("Cache-Control","no-store");x.getResponseHeaders().set("X-Content-Type-Options","nosniff");x.getResponseHeaders().set("X-Frame-Options","DENY");x.sendResponseHeaders(code,b.length);x.getResponseBody().write(b);x.close();}
 static void redirect(HttpExchange x,String to)throws Exception{x.getResponseHeaders().set("Location",to);x.sendResponseHeaders(303,-1);x.close();}
 static String page(String title,String body,Session s){String nav="";if(s!=null)nav="<header><b>SAEP · Assistência técnica</b><span>"+esc(s.name)+"</span></header><nav><a href='/'>Início</a><a href='/clientes'>Clientes</a><a href='/equipamentos'>Equipamentos</a><a href='/agendamentos'>Agendamentos</a><form method='post' action='/logout'>"+csrf(s)+"<button>Sair</button></form></nav>";return "<!doctype html><html lang='pt-BR'><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>"+esc(title)+" | SAEP</title><style>body{margin:0;background:#f1f5f9;color:#183047;font:16px Arial}header,nav{display:flex;gap:24px;align-items:center;background:#17334e;color:white;padding:20px 5%}header span{margin-left:auto}nav{background:#235772;padding:12px 5%}nav a{color:white}a{color:#096777}main{max-width:1200px;margin:30px auto;background:white;padding:28px;border-radius:12px}label{display:block;margin:15px 0}input,select{padding:10px;border:1px solid #b8c7d5;border-radius:5px;max-width:100%;box-sizing:border-box}button,.button{padding:11px 16px;border:0;border-radius:5px;background:#107c73;color:white;cursor:pointer}table{width:100%;border-collapse:collapse;font-size:14px}td,th{padding:12px;text-align:left;border-bottom:1px solid #dae3eb}.scroll{overflow:auto}.inline{display:inline}.cards{display:flex;gap:24px;flex-wrap:wrap}.card{padding:28px;background:#eef5fa;border-radius:9px}.error{padding:16px;background:#ffeded;color:#9e2020}small{color:#637385}</style>"+nav+"<main><h1>"+esc(title)+"</h1>"+body+"</main></html>";}
 static String csrf(Session s){return "<input type='hidden' name='csrf' value='"+s.csrf+"'>";}
 static String label(String f){return switch(f){case "cpf"->"CPF";case "cliente_id"->"Cliente";case "equipamento_id"->"Equipamento";case "dia"->"Data e hora";case "descricao"->"Descrição";case "endereco"->"Endereço";case "numero_serie"->"Número de série";default->f.substring(0,1).toUpperCase()+f.substring(1);};}
 static void handle(HttpExchange x)throws Exception{
  String t=x.getRequestURI().getPath().replaceFirst("^/","");Session s=session(x);Map<String,String> p=params(x.getRequestURI().getRawQuery());String method=x.getRequestMethod();
  if(!method.equals("GET")&&!method.equals("POST")){send(x,405,"Método inválido");return;}
  if(method.equals("POST")){
   String origin=x.getRequestHeaders().getFirst("Origin"),host=x.getRequestHeaders().getFirst("Host");if(origin!=null&&!origin.equals("http://"+host)){send(x,403,"Origem inválida");return;}
   byte[] b=x.getRequestBody().readNBytes(10001);if(b.length>10000){send(x,413,"Requisição muito grande");return;}p=params(new String(b,StandardCharsets.UTF_8));
   if(t.equals("login")){
    List<Map<String,String>> rows=query("SELECT * FROM usuarios WHERE usuario=?",p.getOrDefault("usuario",""));
    String stored=rows.isEmpty()?dummyHash:rows.get(0).get("senha_hash");boolean ok=verify(p.getOrDefault("senha",""),stored);
    if(rows.isEmpty()||!ok){send(x,401,page("Falha na autenticação","<p class='error'>Usuário ou senha incorretos.</p><a href='/login'>Tentar novamente</a>",null));return;}
    String id=token();sessions.put(id,new Session(rows.get(0).get("nome"),token(),System.currentTimeMillis()+1800000));x.getResponseHeaders().set("Set-Cookie","sid="+id+"; HttpOnly; SameSite=Strict; Path=/; Max-Age=1800");redirect(x,"/");return;
   }
   if(s==null){redirect(x,"/login");return;}
   if(!MessageDigest.isEqual(p.getOrDefault("csrf","").getBytes(StandardCharsets.UTF_8),s.csrf.getBytes(StandardCharsets.UTF_8))){send(x,403,"Formulário expirado ou inválido");return;}
   if(t.equals("logout")){Session current=s;sessions.values().removeIf(v->v==current);x.getResponseHeaders().set("Set-Cookie","sid=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0");redirect(x,"/login");return;}
   if(!tables.containsKey(t)){send(x,404,"Não encontrado");return;}
   try{
    if(p.getOrDefault("acao","").equals("excluir"))update("DELETE FROM "+t+" WHERE id=?",List.of(p.getOrDefault("id","")));
    else{
     List<String> cols=new ArrayList<>(tables.get(t)),vals=new ArrayList<>();for(String f:cols){String v=p.getOrDefault(f,"").trim();if(v.isEmpty()||v.length()>500)throw new IllegalArgumentException("Preencha todos os campos com até 500 caracteres.");vals.add(v);}
     if(t.equals("clientes")){String cpf=p.get("cpf").replaceAll("[^0-9]","");if(!validCpf(cpf))throw new IllegalArgumentException("CPF inválido.");if(!p.get("email").matches("[^\\s@]+@[^\\s@]+\\.[^\\s@]+"))throw new IllegalArgumentException("E-mail inválido.");vals.set(1,encrypt(cpf));cols.add("cpf_busca");vals.add(fingerprint(cpf));}
     if(t.equals("agendamentos")){try{LocalDateTime.parse(p.get("dia"));}catch(java.time.format.DateTimeParseException e){throw new IllegalArgumentException("Data e hora inválidas.");}if(!List.of("Pendente","Em andamento","Concluído","Cancelado").contains(p.get("status")))throw new IllegalArgumentException("Status inválido.");}
     String id=p.getOrDefault("id","");if(!id.isEmpty()){List<String> assignments=new ArrayList<>();for(String f:cols)assignments.add(f+"=?");vals.add(id);update("UPDATE "+t+" SET "+String.join(",",assignments)+" WHERE id=?",vals);}else update("INSERT INTO "+t+" ("+String.join(",",cols)+") VALUES ("+String.join(",",Collections.nCopies(cols.size(),"?"))+")",vals);
    }redirect(x,"/"+t);
   }catch(SQLException e){send(x,400,page("Não foi possível salvar","<p class='error'>Registro duplicado ou vínculo inválido. Exclua primeiro os registros dependentes.</p><a href='/"+t+"'>Voltar</a>",s));}catch(IllegalArgumentException e){send(x,400,page("Não foi possível salvar","<p class='error'>"+esc(e.getMessage())+"</p><a href='/"+t+"'>Voltar</a>",s));}return;
  }
  if(t.equals("login")){send(x,200,page("Entrar","<p>Acesse a gestão da assistência técnica.</p><form method='post'><label>Usuário <input name='usuario' required autocomplete='username'></label><label>Senha <input type='password' name='senha' required autocomplete='current-password'></label><button>Entrar</button></form>",null));return;}
  if(s==null){redirect(x,"/login");return;}
  if(t.isEmpty()){String body="<p>Organize clientes, equipamentos e serviços de manutenção.</p><div class='cards'>";for(String table:tables.keySet())body+="<a class='card' href='/"+table+"'>"+label(table)+"<h2>"+query("SELECT COUNT(*) AS total FROM "+table).get(0).get("total")+"</h2></a>";send(x,200,page("Painel de atendimento",body+"</div><p><small>Sessão válida por 30 minutos após o login.</small></p>",s));return;}
  if(!tables.containsKey(t)){send(x,404,page("Página não encontrada","",s));return;}
  String edit=p.getOrDefault("editar","");Map<String,String> row=new HashMap<>();if(!edit.isEmpty()){List<Map<String,String>> rs=query("SELECT * FROM "+t+" WHERE id=?",edit);if(rs.isEmpty()){send(x,404,"Registro não encontrado");return;}row=rs.get(0);if(t.equals("clientes"))row.put("cpf",decrypt(row.get("cpf")));}
  String search=p.getOrDefault("q","");List<Map<String,String>> rows;
  if(t.equals("clientes")){rows=query("SELECT id,nome,cpf,telefone,email,endereco FROM clientes WHERE LOWER(nome) LIKE LOWER(?) OR LOWER(email) LIKE LOWER(?) OR telefone LIKE ? ORDER BY nome","%"+search+"%","%"+search+"%","%"+search+"%");}
  else if(t.equals("equipamentos"))rows=query("SELECT e.*,c.nome AS cliente FROM equipamentos e JOIN clientes c ON c.id=e.cliente_id ORDER BY e.id");
  else rows=query("SELECT a.*,c.id AS cliente_id,c.nome,c.cpf,c.telefone,c.email,c.endereco,e.tipo,e.marca,e.modelo,e.numero_serie FROM agendamentos a JOIN equipamentos e ON e.id=a.equipamento_id JOIN clientes c ON c.id=e.cliente_id ORDER BY a.dia,a.id");
  for(Map<String,String> r:rows)if(r.containsKey("cpf"))r.put("cpf",decrypt(r.get("cpf")));
  StringBuilder body=new StringBuilder();if(t.equals("clientes"))body.append("<form><input name='q' placeholder='Nome, e-mail ou telefone' value='").append(esc(search)).append("'><button>Buscar</button> <a href='/clientes'>Limpar</a></form>");
  body.append("<h2>").append(edit.isEmpty()?"Novo registro":"Editar registro").append("</h2><form method='post'>").append(csrf(s)).append("<input type='hidden' name='id' value='").append(esc(edit)).append("'>");
  for(String f:tables.get(t)){String v=row.getOrDefault(f,"");body.append("<label>").append(label(f)).append(" ");
   if(f.endsWith("_id")||f.equals("status")){List<Map<String,String>> opts=new ArrayList<>();if(f.equals("cliente_id"))opts=query("SELECT id,nome AS texto FROM clientes ORDER BY nome");else if(f.equals("equipamento_id"))opts=query("SELECT e.id,c.nome || ' / ' || e.tipo || ' ' || e.modelo AS texto FROM equipamentos e JOIN clientes c ON c.id=e.cliente_id ORDER BY c.nome");else for(String st:List.of("Pendente","Em andamento","Concluído","Cancelado"))opts.add(Map.of("id",st,"texto",st));body.append("<select required name='").append(f).append("'><option value=''>Selecione</option>");for(Map<String,String> opt:opts)body.append("<option value='").append(esc(opt.get("id"))).append("' ").append(opt.get("id").equals(v)?"selected":"").append(">").append(esc(opt.get("texto"))).append("</option>");body.append("</select>");}
   else body.append("<input required maxlength='500' name='").append(f).append("' type='").append(f.equals("dia")?"datetime-local":f.equals("email")?"email":"text").append("' value='").append(esc(v)).append("'>");body.append("</label>");
  }
  body.append("<button>Salvar</button> <a href='/").append(t).append("'>Cancelar edição</a></form><h2>Registros cadastrados</h2>");
  if(rows.isEmpty())body.append("<p>Nenhum registro encontrado.</p>");else{body.append("<div class='scroll'><table><thead><tr>");for(String f:rows.get(0).keySet())body.append("<th>").append(label(f)).append("</th>");body.append("<th>Ações</th></tr></thead><tbody>");for(Map<String,String> r:rows){body.append("<tr>");for(String v:r.values())body.append("<td>").append(esc(v)).append("</td>");body.append("<td><a href='/").append(t).append("?editar=").append(r.get("id")).append("'>Editar</a> <form class='inline' method='post' onsubmit=\"return confirm('Excluir este registro?')\">").append(csrf(s)).append("<input type='hidden' name='id' value='").append(r.get("id")).append("'><button name='acao' value='excluir'>Excluir</button></form></td></tr>");}body.append("</tbody></table></div>");}
  send(x,200,page(label(t),body.toString(),s));
 }
 static String dummyHash;
 public static void initialize()throws Exception{
  Files.createDirectories(home.resolve("dados"));Path kp=home.resolve("dados/cpf.key");if(!Files.exists(kp)){byte[] k=new byte[32];random.nextBytes(k);Files.write(kp,k);}key=Files.readAllBytes(kp);
  url="jdbc:h2:"+home.resolve("dados/saep").toAbsolutePath()+";DB_CLOSE_ON_EXIT=FALSE";
  boolean empty;try(Connection c=db()){empty=!c.getMetaData().getTables(null,null,"USUARIOS",null).next();}
  if(empty){try(Connection c=db();var reader=Files.newBufferedReader(home.getParent().resolve("saep_db.sql"),StandardCharsets.UTF_8)){RunScript.execute(c,reader);}
   byte[] local=key;key=Base64.getDecoder().decode(Files.readString(home.getParent().resolve("chave_demonstracao.txt")).trim());List<Map<String,String>> rows=query("SELECT id,cpf FROM clientes");List<String> plain=new ArrayList<>();for(var r:rows)plain.add(decrypt(r.get("cpf")));key=local;for(int i=0;i<rows.size();i++)update("UPDATE clientes SET cpf=?,cpf_busca=? WHERE id=?",List.of(encrypt(plain.get(i)),fingerprint(plain.get(i)),rows.get(i).get("id")));}
  dummyHash=hash("dummy-"+token());
 }
 public static void main(String[]args)throws Exception{initialize();HttpServer server=HttpServer.create(new InetSocketAddress("127.0.0.1",8000),0);server.createContext("/",x->{try{handle(x);}catch(Exception e){try{send(x,500,page("Erro interno","Não foi possível concluir a operação.",null));}catch(Exception ignored){x.close();}System.err.println("Falha interna: "+e.getClass().getSimpleName());}});server.setExecutor(Executors.newFixedThreadPool(8));server.start();System.out.println("SAEP Java Web: http://127.0.0.1:8000");}
}
